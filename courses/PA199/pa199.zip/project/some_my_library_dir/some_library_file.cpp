// This is a tutorial file. Feel free to remove it.

#include "some_library_file.hpp"

namespace some_lib {

int some_my_library_function(int x)
{
    return 2*x;
}

}