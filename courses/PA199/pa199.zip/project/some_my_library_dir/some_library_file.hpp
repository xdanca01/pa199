// This is a tutorial file. Feel free to remove it.

#pragma once

namespace some_lib {

int some_my_library_function(int x);

}