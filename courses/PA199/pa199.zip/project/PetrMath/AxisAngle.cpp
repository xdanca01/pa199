// This is a tutorial file. Feel free to remove it.

#include "AxisAngle.hpp"

namespace Petr_Math {
}