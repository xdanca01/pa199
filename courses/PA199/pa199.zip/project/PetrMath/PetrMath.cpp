// This is a tutorial file. Feel free to remove it.

#include "PetrMath.hpp"

namespace Petr_Math {

}