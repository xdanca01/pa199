// This is a tutorial file. Feel free to remove it.

#pragma once

namespace Petr_Math {

int some_my_library_function(int x);

}