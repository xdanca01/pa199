// This is a tutorial file. Feel free to remove it.

#include "some_my_library_dir/some_library_file.hpp"

namespace my_game {

void some_game_function()
{
    some_lib::some_my_library_function(123);
}

}
